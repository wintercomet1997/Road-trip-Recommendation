from django.shortcuts import render
from website.route_generation import *
# Create your views here.

def index(request):
	return render(request,"website/welcome.html")

def welcome(request):
    if request.method == 'GET':
        source="Bangalore"
        destination="Mysore"
        preferences=['Water','Wildlife','Heritage']
        way=thread_create(source,destination,preferences)
        print("Way received in views",way)
        print(request.GET)
        return render(request,"website/welcome.html")
    elif request.method == 'POST':
    	source = request.POST.get('source')
    	destination = request.POST.get('destination')
    	preferences = request.POST.getlist('checks[]')
    	print(source,destination,preferences)
    	way = thread_create(source,destination,preferences)
    	print("Way received in views",way)
    	return render(request,"website/googlemapapi.html", {'route':way})
    